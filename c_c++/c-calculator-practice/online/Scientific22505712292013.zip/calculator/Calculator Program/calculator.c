/*Calculator Program
Author:Himangshu Basistha
www.basistha.com
mail@basistha.com
twitter.com/CenaHustle
*/
#include <stdio.h>
#include <math.h>
#include </header/combination.h>
#include </header/cos.h>
#include </header/cosec.h>
#include </header/cot.h>
#include </header/div.h>
#include </header/fact.h>
#include </header/initials.h>
#include </header/log.h>
#include </header/min.h>
#include </header/mult.h>
#include </header/options.h>
#include </header/permutation.h>
#include </header/pow.h>
#include </header/prime.h>
#include </header/primeinterval.h>
#include </header/sec.h>
#include </header/sin.h>
#include </header/sum.h>
#include </header/tan.h>
#define PI 3.14159265
int main(){
initials();
return 0;
} 
