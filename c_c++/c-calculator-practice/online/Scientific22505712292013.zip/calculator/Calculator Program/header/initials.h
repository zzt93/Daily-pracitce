//mail@basistha.com
int initials(){
printf ("\n\n\t*************************************\n\t*				    *\n\t*  Welcome to C Calculator Program  *\n\t*  Version 0.1			    *\n\t*  Select Option and press enter    *\n\t*				    *\n\t*************************************\n\n");
printf ("Note: Cntrl+C kills any process. Use in case you are unable to exit\nTrigonometric values are not very accurate\n\n\n");
options();
return 0;
}
